provider "aws" {
  region = "ap-south-1"
}

resource "aws_instance" "uptime_monitor" {
  ami = "ami-xxxxxxxx"
  instance_type = "t3.micro"
}
