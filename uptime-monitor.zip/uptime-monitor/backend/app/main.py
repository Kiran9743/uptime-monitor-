from fastapi import FastAPI

app = FastAPI(title="Uptime Monitor API")

@app.get("/")
def root():
    return {"message":"Backend running"}
