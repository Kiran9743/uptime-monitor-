export default function App(){
  return <h1>Uptime Monitor Dashboard</h1>
}
